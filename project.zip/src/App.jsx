import { Question1, Question2, Question3, Question4, Question5 } from './components.jsx';

function App() {
  return (
    <>
      <Question1 />
      <Question2 />
      <Question3 />
      <Question4 />
      <Question5 />

    </>
  )
}

export default App
